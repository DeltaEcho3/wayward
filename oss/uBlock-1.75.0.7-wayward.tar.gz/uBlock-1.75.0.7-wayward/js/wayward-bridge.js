/*******************************************************************************

    uBlock Origin - a comprehensive, efficient content blocker
    Copyright (C) 2014-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock

    ---------------------------------------------------------------------------

    Modified by Wayward (2026-10-27, 2026-10-28, 2026-10-31). This file was added by Wayward and is
    not part of uBlock Origin; background.html gained one line that loads it.
    See WAYWARD-CHANGES.txt.

    It lets Wayward's own built-in extension (agent@wayward.deltaecho), and
    nothing else, read and change uBlock Origin's choice of filter lists, its
    "no scripting" switch (for every site or one site), and whether it filters
    one site. It only selects lists uBlock Origin already knows; it never adds
    a list from an address.

    It also repairs a start that found no filter lists at all (below), and counts what was
    blocked in regular tabs by host name, for Wayward's blocked stats (below).

*/

import µb from './background.js';
import cacheStorage from './cachestorage.js';
import io from './assets.js';
import { PageStore } from './pagestore.js';
import { sessionSwitches } from './filtering-engines.js';

const WAYWARD = 'agent@wayward.deltaecho';

// A plain host name: lowercase letters, digits, hyphens and dots, no empty labels.
const isHostname = h =>
    typeof h === 'string' && h.length <= 253 && /^[a-z0-9-]+(\.[a-z0-9-]+)*$/.test(h);

const siteURL = hostname => `https://${hostname}/`;

// One of uBO's own lists: not the user's own filters, and not a list added from an address.
const isOwnList = (key, entry) =>
    entry.content === 'filters' && key !== µb.userFiltersPath && !entry.external;

const listSummary = ( ) => {
    const out = [];
    for ( const [ key, entry ] of Object.entries(µb.availableFilterLists) ) {
        if ( isOwnList(key, entry) === false ) { continue; }
        out.push({ key, title: entry.title || key, group: entry.group || '' });
    }
    return out;
};

/******************************************************************************/

// The repair (2026-10-28). From 1.75.0.1 to 1.75.0.3 this copy took itself for a dev build (see
// vapi-common.js), which reads its catalogue of filter lists from a file that isn't bundled. So a
// new install's first start knew no lists, chose only the user's own filters, and kept that: no
// ad blocking, for good. Once uBO is ready at each start, if it knows no lists of its own, or its
// last start saved none and none of its lists is chosen, the state that start left is cleared and
// uBO restarts, so its first-start setup runs again. At most twice ever, so a catalogue that can't
// be read doesn't restart it over and over.
const REPAIRS = 'waywardListRepairs';
const MAX_REPAIRS = 2;
// Lists added from an address, chosen when a repair cleared the choice: chosen again after the
// restart, next to the lists uBO then picks (ultra review 5).
const KEPT = 'waywardKeptLists';
const isAddressKey = k => /^[a-z-]+:\/\//.test(k);

const restoreKept = async ( ) => {
    const bin = await vAPI.storage.get(KEPT);
    const kept = bin instanceof Object && Array.isArray(bin[KEPT]) ? bin[KEPT] : [];
    if ( kept.length === 0 ) { return; }
    // An address that's one of uBO's own lists is that list now (as uBO maps an import).
    const lists = Object.entries(µb.availableFilterLists);
    const keyOf = url => {
        if ( µb.availableFilterLists[url] instanceof Object ) { return url; }
        const needle = url.replace(/^https?:/, '');
        const own = lists.find(([ , e ]) => e.content === 'filters' && typeof e.contentURL === 'string' && e.contentURL.endsWith(needle));
        return own ? own[0] : null;
    };
    const toSelect = kept.map(keyOf).filter(k => k !== null);
    if ( toSelect.length !== 0 ) {
        µb.applyFilterListSelection({ toSelect, merge: true });
        reloadLists();
    }
    await vAPI.storage.remove(KEPT);
};

const knowsLists = lists =>
    lists instanceof Object && Object.entries(lists).some(([ k, e ]) => e instanceof Object && isOwnList(k, e));

// The lists uBO's last start saved, read now, before this start saves its own.
const lastLists = vAPI.storage.get('availableFilterLists').then(bin => bin && bin.availableFilterLists);

// Resolves true when a repair is under way and uBO is about to restart.
const repairing = (async ( ) => {
    await µb.isReadyPromise;
    const last = await lastLists;
    // Lists added from an address are kept as they are; the user's own filters are always chosen.
    const ownChosen = µb.selectedFilterLists.some(k =>
        k !== µb.userFiltersPath && isAddressKey(k) === false
    );
    const broken = knowsLists(µb.availableFilterLists) === false ||
        last instanceof Object && knowsLists(last) === false && ownChosen === false;
    if ( broken === false ) {
        await restoreKept();
        return false;
    }
    const bin = await vAPI.storage.get(REPAIRS);
    const done = bin instanceof Object && bin[REPAIRS] || 0;
    if ( done >= MAX_REPAIRS ) {
        console.warn(`[Wayward] uBO's filter lists are broken (a start found none); ${done} repairs already, no more`);
        return false;
    }
    // Wayward grants uBO private browsing when it starts it for the first time, which restarts it
    // half a second later: waiting a moment keeps a repair from being cut short by that.
    await vAPI.defer.once(3000);
    console.info(`[Wayward] uBO's filter lists are broken (a start found none): repair ${done + 1} of ${MAX_REPAIRS}, then a restart`);
    await vAPI.storage.set({ [REPAIRS]: done + 1 });
    // The choice goes, but not the lists added from an address in it.
    const kept = ownChosen ? [] : µb.selectedFilterLists.filter(isAddressKey);
    if ( kept.length !== 0 ) { await vAPI.storage.set({ [KEPT]: kept }); }
    // The broken start's choice (kept if it has lists of uBO's own), its catalogue, the lists'
    // details, and the filtering engine's saved copy, which a start uses instead of the lists.
    await Promise.all([
        vAPI.storage.remove(ownChosen ? [ 'availableFilterLists' ] : [ 'selectedFilterLists', 'availableFilterLists' ]),
        cacheStorage.remove('assetSourceRegistry'),
        io.remove(/^selfie\/static/),
    ]);
    // cacheStorage.remove doesn't wait for its IndexedDB copy to go; a read after it does.
    await cacheStorage.get('assetSourceRegistry');
    vAPI.app.restart();
    return true;
})().catch(e => {
    console.error('[Wayward] uBO list repair failed', e);
    return false;
});

// A reload of the lists that's already running read the selection when it started, and uBO hands
// that same reload to anyone who asks for another meanwhile: a change made then was saved but never
// filtered with (ultra review). So the reload in progress, whoever started it, is known here, and a
// change made during one gets one more reload after it, which reads the latest selection.
let listsLoading = null;
let listsQueued = null;
const uboLoadFilterLists = µb.loadFilterLists;
µb.loadFilterLists = function( ) {
    const p = uboLoadFilterLists.call(this);
    if ( p !== listsLoading ) {
        listsLoading = p;
        const clear = ( ) => { if ( listsLoading === p ) { listsLoading = null; } };
        p.then(clear, clear);
    }
    return p;
};
const reloadLists = ( ) => {
    if ( listsLoading === null ) { µb.loadFilterLists(); return; }
    if ( listsQueued !== null ) { return; }
    const after = ( ) => { listsQueued = null; µb.loadFilterLists(); };
    listsQueued = listsLoading.then(after, after);
};

/******************************************************************************/

// What was blocked, by host (2026-10-31): for each tab, how many of each host's requests uBO
// blocked, kept in memory until Wayward takes it for its blocked stats. Wayward keeps only the tabs
// its history would record (not locked tabs, nor with history off). Never a private tab's requests,
// nor those of a tab not known yet or of no tab at all, never full addresses, and at most MAX_HOSTS
// counts between takes.
const MAX_HOSTS = 500;
// Tab id -> Map(host name -> count).
const blockedHosts = new Map();
let blockedCount = 0;
// Each tab's id: true for a private one.
const tabPrivate = new Map();
const noteTab = tab => {
    if ( tab instanceof Object && Number.isInteger(tab.id) ) { tabPrivate.set(tab.id, tab.incognito === true); }
};
browser.tabs.query({}).then(tabs => { tabs.forEach(noteTab); }, ( ) => { });
browser.tabs.onCreated.addListener(noteTab);
browser.tabs.onUpdated.addListener((id, info, tab) => { noteTab(tab); });
browser.tabs.onRemoved.addListener(id => { tabPrivate.delete(id); });

// uBO's page store writes each request to a journal (host name, 1 if blocked, type) and tallies it
// in journalProcess, which then empties it: read first.
const uboJournalProcess = PageStore.prototype.journalProcess;
PageStore.prototype.journalProcess = function( ) {
    if ( tabPrivate.get(this.tabId) === false ) {
        const journal = this.journal;
        let hosts = blockedHosts.get(this.tabId);
        for ( let i = 0; i < journal.length; i += 3 ) {
            if ( journal[i+1] !== 1 ) { continue; }
            const host = journal[i+0];
            const n = hosts !== undefined ? hosts.get(host) : undefined;
            if ( n !== undefined ) {
                hosts.set(host, n + 1);
            } else if ( blockedCount < MAX_HOSTS ) {
                if ( hosts === undefined ) {
                    hosts = new Map();
                    blockedHosts.set(this.tabId, hosts);
                }
                hosts.set(host, 1);
                blockedCount += 1;
            }
        }
    }
    return uboJournalProcess.call(this);
};

const takeBlockedHosts = ( ) => {
    const tabs = {};
    for ( const [ tabId, hosts ] of blockedHosts ) { tabs[tabId] = Object.fromEntries(hosts); }
    blockedHosts.clear();
    blockedCount = 0;
    return tabs;
};

const handle = async msg => {
    await µb.isReadyPromise;
    // Wayward asks again until uBO has restarted with its lists.
    if ( await repairing ) { return { ok: false, error: 'uBlock Origin is repairing its filter lists' }; }
    switch ( msg.action ) {
    case 'getState':
        return {
            ok: true,
            version: browser.runtime.getManifest().version,
            selected: Array.from(µb.selectedFilterLists),
            lists: listSummary(),
            scriptsBlocked: sessionSwitches.evaluateZ('no-scripting', '*') === true,
        };
    case 'setLists': {
        if ( Array.isArray(msg.lists) === false ) { return { ok: false, error: 'bad lists' }; }
        const known = new Set(listSummary().map(l => l.key));
        const toSelect = msg.lists.filter(k => typeof k === 'string' && known.has(k));
        // Lists Wayward doesn't offer stay as they are: the user's own filters, and lists imported
        // from an address in uBlock Origin's own dashboard (code review of 3bf5006~1..cee8f4c).
        for ( const k of µb.selectedFilterLists ) {
            if ( known.has(k) === false && toSelect.includes(k) === false ) { toSelect.push(k); }
        }
        µb.applyFilterListSelection({ toSelect });
        // Lists not on the phone yet download from their usual servers.
        reloadLists();
        return { ok: true, selected: toSelect };
    }
    case 'setScriptsBlocked':
        if ( typeof msg.blocked !== 'boolean' ) { return { ok: false, error: 'bad value' }; }
        µb.toggleHostnameSwitch({ name: 'no-scripting', hostname: '*', state: msg.blocked, persist: true });
        return { ok: true };
    case 'getSite':
        if ( isHostname(msg.hostname) === false ) { return { ok: false, error: 'bad host' }; }
        return {
            ok: true,
            scriptsBlocked: sessionSwitches.evaluateZ('no-scripting', msg.hostname) === true,
            filtering: µb.getNetFilteringSwitch(siteURL(msg.hostname)),
        };
    case 'setSiteScripts':
        if ( isHostname(msg.hostname) === false || typeof msg.blocked !== 'boolean' ) {
            return { ok: false, error: 'bad value' };
        }
        µb.toggleHostnameSwitch({ name: 'no-scripting', hostname: msg.hostname, state: msg.blocked, persist: true });
        return { ok: true };
    case 'setSiteFiltering':
        if ( isHostname(msg.hostname) === false || typeof msg.on !== 'boolean' ) {
            return { ok: false, error: 'bad value' };
        }
        µb.toggleNetFilteringSwitch(siteURL(msg.hostname), '', msg.on);
        return { ok: true };
    case 'takeBlockedHosts':
        return { ok: true, tabs: takeBlockedHosts() };
    default:
        return { ok: false, error: 'unknown action' };
    }
};

browser.runtime.onMessageExternal.addListener((msg, sender) => {
    if ( sender.id !== WAYWARD || msg === null || typeof msg !== 'object' ) { return; }
    return handle(msg).catch(e => ({ ok: false, error: String(e && e.message || e) }));
});
