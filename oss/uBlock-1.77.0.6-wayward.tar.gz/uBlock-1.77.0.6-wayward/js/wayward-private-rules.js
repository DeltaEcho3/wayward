/*******************************************************************************

    uBlock Origin - a comprehensive, efficient content blocker
    Copyright (C) 2014-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock

    ---------------------------------------------------------------------------

    Modified by Wayward (2026-11-25).
    This file was added by Wayward and is not part of uBlock Origin; js/messaging.js and
    js/wayward-bridge.js import it. See WAYWARD-CHANGES.txt.

    Dynamic filtering rules set from a private tab, or from a tab not known to be regular: the panel's
    rules (advanced mode) and the logger's URL rules. They act in every tab until uBlock Origin restarts,
    as any temporary rule does, but no save takes them: before the saved rules are written (My rules'
    Commit, the panel's lock, the logger's Save, a Ctrl or Meta click), each such rule in them is put back
    as it was when the private tab first set it. A rule set again from a regular tab, or edited in My rules,
    is that tab's own and saved as usual. Kept in memory only.

*/

import {
    permanentFirewall,
    permanentURLFiltering,
    sessionFirewall,
    sessionURLFiltering,
} from './filtering-engines.js';

/******************************************************************************/

// Rule ("source destination type" or "context url type") -> its action in the saved rules when a private tab
// first set it (0 for none).
const firewallRules = new Map();
const urlRules = new Map();

const urlRuleAction = (ruleset, context, url, type) => {
    const entries = ruleset.rules.get(`${context} ${type}`);
    if ( entries === undefined ) { return 0; }
    for ( const entry of entries ) {
        if ( entry.url === url ) { return entry.action; }
    }
    return 0;
};

const isPart = s => typeof s === 'string' && s !== '' && /\s/.test(s) === false;

// A firewall rule set (or unset) from the panel, fromPrivate when its tab isn't known to be regular.
const noteFirewallRule = (fromPrivate, srcHostname, desHostname, type) => {
    if ( isPart(srcHostname) === false || isPart(desHostname) === false || isPart(type) === false ) { return; }
    const key = `${srcHostname} ${desHostname} ${type}`;
    if ( fromPrivate !== true ) {
        firewallRules.delete(key);
        return;
    }
    if ( firewallRules.has(key) ) { return; }
    firewallRules.set(key, permanentFirewall.evaluateCell(srcHostname, desHostname, type));
};

// A URL rule set (or unset) from the logger, fromPrivate when the logger's tab or the row's tab isn't known to be
// regular.
const noteURLRule = (fromPrivate, context, url, type) => {
    if ( isPart(context) === false || isPart(url) === false || isPart(type) === false ) { return; }
    const key = `${context} ${url} ${type}`;
    if ( fromPrivate !== true ) {
        urlRules.delete(key);
        return;
    }
    if ( urlRules.has(key) ) { return; }
    urlRules.set(key, urlRuleAction(permanentURLFiltering, context, url, type));
};

// Rules typed or removed in My rules (its own text, one rule a line): the user's own, saved as usual.
const noteEditedRules = text => {
    if ( typeof text !== 'string' ) { return; }
    for ( const line of text.split(/[\n\r]+/) ) {
        const parts = line.trim().split(/\s+/);
        if ( parts.length < 3 ) { continue; }
        const key = `${parts[0]} ${parts[1]} ${parts[2]}`;
        firewallRules.delete(key);
        urlRules.delete(key);
    }
};

// Before the saved rules are written: each rule a private tab set is put back as the saved rules had it.
const leaveOutPrivateRules = ( ) => {
    for ( const [ key, action ] of firewallRules ) {
        const [ src, des, type ] = key.split(' ');
        if ( permanentFirewall.evaluateCell(src, des, type) !== action ) {
            permanentFirewall.setCell(src, des, type, action);
        }
    }
    for ( const [ key, action ] of urlRules ) {
        const [ context, url, type ] = key.split(' ');
        if ( urlRuleAction(permanentURLFiltering, context, url, type) !== action ) {
            permanentURLFiltering.setRule(context, url, type, action);
        }
    }
};

// How many rules a private tab set still differ from the saved ones (My rules says they aren't saved).
const privateRulesLeft = ( ) => {
    let n = 0;
    for ( const [ key, action ] of firewallRules ) {
        const [ src, des, type ] = key.split(' ');
        if ( sessionFirewall.evaluateCell(src, des, type) !== action ) { n += 1; }
    }
    for ( const [ key, action ] of urlRules ) {
        const [ context, url, type ] = key.split(' ');
        if ( urlRuleAction(sessionURLFiltering, context, url, type) !== action ) { n += 1; }
    }
    return n;
};

export {
    leaveOutPrivateRules,
    noteEditedRules,
    noteFirewallRule,
    noteURLRule,
    privateRulesLeft,
};
