/*******************************************************************************

    uBlock Origin - a comprehensive, efficient content blocker
    Copyright (C) 2014-present Raymond Hill

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see {http://www.gnu.org/licenses/}.

    Home: https://github.com/gorhill/uBlock

    ---------------------------------------------------------------------------

    Modified by Wayward (2026-10-27). This file was added by Wayward and is
    not part of uBlock Origin; background.html gained one line that loads it.
    See WAYWARD-CHANGES.txt.

    It lets Wayward's own built-in extension (agent@wayward.deltaecho), and
    nothing else, read and change uBlock Origin's choice of filter lists, its
    "no scripting" switch (for every site or one site), and whether it filters
    one site. It only selects lists uBlock Origin already knows; it never adds
    a list from an address.

*/

import µb from './background.js';
import { sessionSwitches } from './filtering-engines.js';

const WAYWARD = 'agent@wayward.deltaecho';

// A plain host name: lowercase letters, digits, hyphens and dots, no empty labels.
const isHostname = h =>
    typeof h === 'string' && h.length <= 253 && /^[a-z0-9-]+(\.[a-z0-9-]+)*$/.test(h);

const siteURL = hostname => `https://${hostname}/`;

const listSummary = ( ) => {
    const out = [];
    for ( const [ key, entry ] of Object.entries(µb.availableFilterLists) ) {
        if ( entry.content !== 'filters' ) { continue; }
        // The user's own filters and lists added from an address aren't offered.
        if ( key === µb.userFiltersPath || entry.external ) { continue; }
        out.push({ key, title: entry.title || key, group: entry.group || '' });
    }
    return out;
};

const handle = async msg => {
    await µb.isReadyPromise;
    switch ( msg.action ) {
    case 'getState':
        return {
            ok: true,
            version: browser.runtime.getManifest().version,
            selected: Array.from(µb.selectedFilterLists),
            lists: listSummary(),
            scriptsBlocked: sessionSwitches.evaluateZ('no-scripting', '*') === true,
        };
    case 'setLists': {
        if ( Array.isArray(msg.lists) === false ) { return { ok: false, error: 'bad lists' }; }
        const known = new Set(listSummary().map(l => l.key));
        const toSelect = msg.lists.filter(k => typeof k === 'string' && known.has(k));
        // Lists Wayward doesn't offer stay as they are: the user's own filters, and lists imported
        // from an address in uBlock Origin's own dashboard (code review of 3bf5006~1..cee8f4c).
        for ( const k of µb.selectedFilterLists ) {
            if ( known.has(k) === false && toSelect.includes(k) === false ) { toSelect.push(k); }
        }
        µb.applyFilterListSelection({ toSelect });
        // Lists not on the phone yet download from their usual servers.
        µb.loadFilterLists();
        return { ok: true, selected: toSelect };
    }
    case 'setScriptsBlocked':
        if ( typeof msg.blocked !== 'boolean' ) { return { ok: false, error: 'bad value' }; }
        µb.toggleHostnameSwitch({ name: 'no-scripting', hostname: '*', state: msg.blocked, persist: true });
        return { ok: true };
    case 'getSite':
        if ( isHostname(msg.hostname) === false ) { return { ok: false, error: 'bad host' }; }
        return {
            ok: true,
            scriptsBlocked: sessionSwitches.evaluateZ('no-scripting', msg.hostname) === true,
            filtering: µb.getNetFilteringSwitch(siteURL(msg.hostname)),
        };
    case 'setSiteScripts':
        if ( isHostname(msg.hostname) === false || typeof msg.blocked !== 'boolean' ) {
            return { ok: false, error: 'bad value' };
        }
        µb.toggleHostnameSwitch({ name: 'no-scripting', hostname: msg.hostname, state: msg.blocked, persist: true });
        return { ok: true };
    case 'setSiteFiltering':
        if ( isHostname(msg.hostname) === false || typeof msg.on !== 'boolean' ) {
            return { ok: false, error: 'bad value' };
        }
        µb.toggleNetFilteringSwitch(siteURL(msg.hostname), '', msg.on);
        return { ok: true };
    default:
        return { ok: false, error: 'unknown action' };
    }
};

browser.runtime.onMessageExternal.addListener((msg, sender) => {
    if ( sender.id !== WAYWARD || msg === null || typeof msg !== 'object' ) { return; }
    return handle(msg).catch(e => ({ ok: false, error: String(e && e.message || e) }));
});
